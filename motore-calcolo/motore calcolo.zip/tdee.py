#!/usr/bin/env python3
"""
Modulo stima TDEE - Studio Nutrizionale Taglialatela

Calcola una PROPOSTA di TDEE e di target.csv di partenza dai dati del
fascicolo paziente. Il valore resta sempre da confermare dal nutrizionista:
questo modulo non decide il piano, propone un punto di partenza.

Formula: Mifflin-St Jeor (la piu' validata su popolazione generale).
    Uomo:  BMR = 10*peso_kg + 6.25*altezza_cm - 5*eta_anni + 5
    Donna: BMR = 10*peso_kg + 6.25*altezza_cm - 5*eta_anni - 161

Fattori di attivita' (PAL) standard:
    sedentario        1.20
    leggero           1.375
    moderato          1.55
    intenso           1.725
    molto_intenso     1.90
"""

from larn import riferimenti as riferimenti_larn

PAL = {
    "sedentario": 1.20,
    "leggero": 1.375,
    "moderato": 1.55,
    "intenso": 1.725,
    "molto_intenso": 1.90,
}


def calcola_bmr(peso_kg, altezza_cm, eta_anni, sesso):
    base = 10 * peso_kg + 6.25 * altezza_cm - 5 * eta_anni
    if sesso.upper() == "M":
        return base + 5
    elif sesso.upper() == "F":
        return base - 161
    else:
        raise ValueError("sesso deve essere 'M' o 'F'")


def proponi_tdee(peso_kg, altezza_cm, eta_anni, sesso, livello_attivita):
    if livello_attivita not in PAL:
        raise ValueError(f"livello_attivita deve essere uno tra: {list(PAL)}")
    bmr = calcola_bmr(peso_kg, altezza_cm, eta_anni, sesso)
    tdee = bmr * PAL[livello_attivita]
    return {
        "bmr_kcal": round(bmr, 1),
        "fattore_attivita": PAL[livello_attivita],
        "tdee_stimato_kcal": round(tdee, 1),
        "formula": "Mifflin-St Jeor",
        "nota": "Valore di partenza da confermare dal nutrizionista in base a "
                "obiettivo (mantenimento/deficit/surplus) e quadro clinico. "
                "Non sostituisce la valutazione clinica.",
    }


def proponi_target_csv(tdee_kcal, tipo_piano, proteine_pct, carboidrati_pct,
                       grassi_pct, fibra_g_target, sesso=None, eta_anni=None,
                       condizione="nessuna", larn=None):
    """
    tipo_piano: 'mantenimento' | 'deficit_lieve' (-15%) | 'deficit_moderato' (-25%)
                | 'surplus_lieve' (+10%)
    I LARN si leggono da larn.csv per sesso, eta' e condizione (nessuna |
    menopausa | gravidanza | allattamento). Non esistono valori di default:
    senza sesso ed eta' il modulo si ferma. Con larn={...} si possono forzare
    singoli valori (uso clinico motivato), ma restano sovrascritture esplicite.
    Restituisce le righe pronte per target.csv (il nutrizionista conferma
    prima di salvare).
    """
    fattori = {
        "mantenimento": 1.0,
        "deficit_lieve": 0.85,
        "deficit_moderato": 0.75,
        "surplus_lieve": 1.10,
    }
    if tipo_piano not in fattori:
        raise ValueError(f"tipo_piano deve essere uno tra: {list(fattori)}")
    kcal_piano = round(tdee_kcal * fattori[tipo_piano])

    valori_larn, nota_larn = riferimenti_larn(sesso, eta_anni, condizione)
    if larn:
        valori_larn = dict(valori_larn)
        valori_larn.update(larn)

    righe = {
        "kcal_target": kcal_piano,
        "proteine_pct_target": proteine_pct,
        "carboidrati_pct_target": carboidrati_pct,
        "grassi_pct_target": grassi_pct,
        "fibra_g_target": fibra_g_target,
        **valori_larn,
    }
    return righe


if __name__ == "__main__":
    # Esempio di verifica con Vittorio Taglialatela (36 anni, M, 180cm, 75kg, sedentario)
    r = proponi_tdee(75, 180, 36, "M", "sedentario")
    print("TDEE proposto:", r)
    assert abs(r["tdee_stimato_kcal"] - 2040) < 1, "Non coincide col TDEE gia' approvato per Vittorio"
    t = proponi_target_csv(r["tdee_stimato_kcal"], "mantenimento", 22, 48, 30, 30,
                           sesso="M", eta_anni=36)
    print("Target proposto:", t)
    assert t["larn_vitamina_b12_ug"] == 4.0, "LARN non letti dalla tabella V revisione"
    try:
        proponi_target_csv(2000, "mantenimento", 22, 48, 30, 30)
    except ValueError:
        print("OK: senza sesso ed eta' il modulo si ferma invece di usare default.")
    else:
        raise AssertionError("avrebbe dovuto fermarsi senza sesso ed eta'")
    print("\nVerifica OK: coincide con il TDEE 2040 kcal gia' confermato manualmente per Vittorio.")
