#!/usr/bin/env python3
"""
Collaudo di inizio sessione - Studio Nutrizionale Taglialatela
FASE 0.1 del progetto di consolidamento motore.

Certificato che va eseguito ad ogni apertura di sessione di calcolo, PRIMA
di qualsiasi calcolo su paziente. Se anche un solo controllo fallisce, lo
script esce con codice diverso da zero e non va usato il motore finche' il
problema non e' risolto.

CONTROLLI:
  1) Integrita' e presenza di tutti i CSV del motore (parsing senza errori
     E numero di colonne coerente con l'header su ogni riga)
  2) Conteggio righe di alimenti.csv contro il valore atteso dichiarato
  3) Assenza di food_id duplicati in alimenti.csv
  4) Esecuzione di una giornata golden, confrontata al risultato atteso

NOTA SUL VALORE ATTESO (punto 2):
  EXPECTED_ALIMENTI_COUNT va aggiornato ogni volta che il database cresce
  (criterio Key Foods, protocollo di estrazione). Non e' pensato per essere
  dedotto automaticamente: se il conteggio reale non corrisponde, il motivo
  puo' essere un aggiornamento legittimo non ancora registrato qui, oppure
  un problema reale (parsing rotto, file scaricato a meta'). Il collaudo
  non decide da solo quale dei due casi sia: si ferma e lo segnala.

NOTA SULLA GIORNATA GOLDEN (punto 4):
  Usa i CSV di test che accompagnano il motore (alimenti_test.csv,
  piano_test.csv), non dati di pazienti reali: i dati clinici non vivono in
  questo repository (separazione GitHub/Drive, vedi istruzioni di progetto).
  E' un test di REGRESSIONE DEL CODICE, non una validazione clinica: verifica
  che calcolatore.py produca ancora gli stessi numeri su un input fisso e
  noto, non che quei numeri siano clinicamente corretti per un paziente.
"""

import csv
import os
import sys

BASE = os.path.dirname(os.path.abspath(__file__))

# --- valore da aggiornare manualmente quando il database cresce ---
EXPECTED_ALIMENTI_COUNT = 121

# file dello schema congelato + file di test che devono esistere ed essere
# parsabili. I _test.csv viaggiano con il motore; gli altri (piano.csv,
# target.csv, farmaci_paziente.csv, interazioni.csv, orari_pasti.csv) sono
# per-paziente e vivono su Drive: qui si controllano solo i file che DEVONO
# essere presenti in questa cartella ad ogni sessione.
FILE_DA_VERIFICARE = [
    "alimenti.csv",
    "alimenti_test.csv",
    "piano_test.csv",
    "piano_test_scelte.csv",
    "target_test.csv",
    "farmaci_paziente_test.csv",
    "interazioni_test.csv",
    "orari_pasti_test.csv",
]

# riferimento golden: totali esatti attesi per la giornata 1 di
# piano_test.csv + alimenti_test.csv (calcolati una volta, congelati qui)
GOLDEN_ATTESO = {
    "kcal_100g": 1500.0,
    "proteine_g": 75.5,
    "carboidrati_g": 185.0,
    "grassi_g": 46.5,
    "fibra_g": 24.0,
    "calcio_mg": 290.0,
    "ferro_mg": 8.25,
    "vitamina_d_ug": 4.0,
    "folati_ug": 122.5,
    "vitamina_b12_ug": 2.5,
    "zinco_mg": 6.300000000000001,
    "magnesio_mg": 132.5,
    "vitamina_c_mg": 100.0,
}
GOLDEN_TOLLERANZA_ASSOLUTA = 0.01  # e' un test di regressione: deve tornare
                                    # identico, non solo "vicino"


def controllo_1_integrita_csv():
    """Presenza + parsing senza errori di tutti i file richiesti."""
    esiti = []
    for nome_file in FILE_DA_VERIFICARE:
        path = os.path.join(BASE, nome_file)
        if not os.path.isfile(path):
            esiti.append((nome_file, False, "file mancante"))
            continue
        try:
            with open(path, newline="", encoding="utf-8") as f:
                righe = list(csv.DictReader(f))
            if not righe:
                esiti.append((nome_file, False, "file presente ma vuoto (0 righe dati)"))
                continue
            righe_malformate = []
            for i, row in enumerate(righe, start=2):  # riga 1 = header
                if None in row or any(v is None for v in row.values()):
                    righe_malformate.append(i)
            if righe_malformate:
                esiti.append((nome_file, False,
                    f"{len(righe)} righe lette ma {len(righe_malformate)} "
                    f"malformate (colonne diverse dall'header) a riga {righe_malformate}"))
            else:
                esiti.append((nome_file, True, f"{len(righe)} righe, parsing ok"))
        except Exception as e:
            esiti.append((nome_file, False, f"errore di parsing: {e}"))
    return esiti


def controllo_2_conteggio_alimenti():
    path = os.path.join(BASE, "alimenti.csv")
    if not os.path.isfile(path):
        return False, "alimenti.csv non trovato, impossibile contare le righe"
    with open(path, newline="", encoding="utf-8") as f:
        n = len(list(csv.DictReader(f)))
    if n == EXPECTED_ALIMENTI_COUNT:
        return True, f"{n} righe, come atteso"
    return False, (
        f"{n} righe trovate, {EXPECTED_ALIMENTI_COUNT} attese. "
        f"Verifica se e' un aggiornamento legittimo del database non ancora "
        f"registrato in EXPECTED_ALIMENTI_COUNT, oppure un problema reale."
    )


def controllo_3_duplicati_food_id():
    path = os.path.join(BASE, "alimenti.csv")
    if not os.path.isfile(path):
        return False, "alimenti.csv non trovato, impossibile controllare i duplicati"
    with open(path, newline="", encoding="utf-8") as f:
        ids = [row["food_id"] for row in csv.DictReader(f)]
    duplicati = sorted(set(x for x in ids if ids.count(x) > 1))
    if not duplicati:
        return True, "nessun food_id duplicato"
    return False, f"food_id duplicati: {', '.join(duplicati)}"


def controllo_4_giornata_golden():
    try:
        from calcolatore import carica_alimenti, carica_piano, calcola_riga, somma_nutrienti
    except Exception as e:
        return False, f"impossibile importare calcolatore.py: {e}"

    path_alimenti = os.path.join(BASE, "alimenti_test.csv")
    path_piano = os.path.join(BASE, "piano_test.csv")
    if not (os.path.isfile(path_alimenti) and os.path.isfile(path_piano)):
        return False, "alimenti_test.csv o piano_test.csv mancanti"

    try:
        db = carica_alimenti(path_alimenti)
        piano = carica_piano(path_piano)
        righe = [calcola_riga(db[r["food_id"]], r["grammi"]) for r in piano]
        tot = somma_nutrienti(righe)
    except Exception as e:
        return False, f"errore durante l'esecuzione del calcolo golden: {e}"

    scarti = []
    for nutriente, atteso in GOLDEN_ATTESO.items():
        reale = tot.get(nutriente)
        if reale is None:
            scarti.append(f"{nutriente}: nutriente assente nel risultato")
            continue
        if abs(reale - atteso) > GOLDEN_TOLLERANZA_ASSOLUTA:
            scarti.append(f"{nutriente}: atteso {atteso}, ottenuto {reale}")

    if not scarti:
        return True, "output identico al riferimento golden"
    return False, "scostamenti dal riferimento golden -> " + "; ".join(scarti)


def main():
    print("=" * 60)
    print("COLLAUDO DI INIZIO SESSIONE - Motore di calcolo")
    print("=" * 60)

    tutto_ok = True

    print("\n1) Integrita' e presenza dei CSV")
    for nome_file, ok, dettaglio in controllo_1_integrita_csv():
        simbolo = "OK " if ok else "XX "
        print(f"   [{simbolo}] {nome_file}: {dettaglio}")
        tutto_ok = tutto_ok and ok

    print("\n2) Conteggio righe alimenti.csv")
    ok, dettaglio = controllo_2_conteggio_alimenti()
    print(f"   [{'OK ' if ok else 'XX '}] {dettaglio}")
    tutto_ok = tutto_ok and ok

    print("\n3) Duplicati food_id in alimenti.csv")
    ok, dettaglio = controllo_3_duplicati_food_id()
    print(f"   [{'OK ' if ok else 'XX '}] {dettaglio}")
    tutto_ok = tutto_ok and ok

    print("\n4) Giornata golden (regressione codice, non validazione clinica)")
    ok, dettaglio = controllo_4_giornata_golden()
    print(f"   [{'OK ' if ok else 'XX '}] {dettaglio}")
    tutto_ok = tutto_ok and ok

    print("\n" + "=" * 60)
    if tutto_ok:
        print("COLLAUDO SUPERATO - motore utilizzabile per questa sessione")
    else:
        print("COLLAUDO FALLITO - non usare il motore su un paziente finche'")
        print("le anomalie sopra non sono state risolte")
    print("=" * 60)

    sys.exit(0 if tutto_ok else 1)


if __name__ == "__main__":
    main()
