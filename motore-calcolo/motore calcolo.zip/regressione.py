#!/usr/bin/env python3
"""
Suite di regressione - Studio Nutrizionale Taglialatela
FASE 1 del progetto di consolidamento motore.

COSA FA
Riesegue tutte le giornate golden archiviate in golden/ e confronta i totali
prodotti dal motore con i valori attesi congelati in atteso.json.

QUANDO SI ESEGUE
Per regola dopo OGNI modifica al motore o al database alimenti, e comunque
prima di qualsiasi uso clinico. Il collaudo (collaudo.py) dice che i dati sono
integri; questa suite dice che il motore calcola ancora come prima.

COSA NON E'
Non e' una validazione clinica. Verifica che il motore produca gli stessi
numeri su input fissi e noti, non che quei numeri siano giusti per un
paziente. Un caso golden congelato con un valore atteso sbagliato continuera'
a passare: e' per questo che ogni atteso.json va generato solo dopo che il
risultato e' stato verificato, mai "preso per buono" perche' lo dice il motore.

STRUTTURA DI UN CASO
  golden/caso_NN_nome/
      piano.csv     input: composizione della giornata (schema congelato)
      target.csv    input: target e riferimenti LARN
      atteso.json   output atteso: totali giornalieri + metadati del caso

I casi non contengono dati identificativi di pazienti: solo food_id e
grammature. Identita', quadro clinico e terapia restano su Drive.

USO
  python3 regressione.py              esegue tutti i casi
  python3 regressione.py --genera     rigenera gli atteso.json (vedi sotto)

--genera va usato SOLO quando una modifica al motore cambia intenzionalmente
i risultati e il nuovo output e' gia' stato verificato a mano. Rigenerare per
far passare una suite rossa senza aver capito perche' era rossa annulla lo
scopo della suite.
"""

import csv
import json
import os
import sys

BASE = os.path.dirname(os.path.abspath(__file__))
GOLDEN_DIR = os.path.join(BASE, "golden")

# tolleranza di confronto: e' un test di regressione, i numeri devono tornare
# identici a meno dell'errore di rappresentazione in virgola mobile
TOLLERANZA = 0.001


def elenca_casi():
    if not os.path.isdir(GOLDEN_DIR):
        return []
    casi = []
    for nome in sorted(os.listdir(GOLDEN_DIR)):
        percorso = os.path.join(GOLDEN_DIR, nome)
        if os.path.isdir(percorso) and os.path.isfile(os.path.join(percorso, "piano.csv")):
            casi.append(nome)
    return casi


def esegui_caso(nome_caso):
    """Esegue un caso e restituisce i totali per pasto e per giorno."""
    from calcolatore import (carica_alimenti, carica_piano, carica_target,
                             calcola_riga, somma_nutrienti, NUTRIENTI_PER_100G)

    percorso = os.path.join(GOLDEN_DIR, nome_caso)
    db = carica_alimenti(os.path.join(BASE, "alimenti.csv"))
    piano = carica_piano(os.path.join(percorso, "piano.csv"))
    target = carica_target(os.path.join(percorso, "target.csv"))

    sconosciuti = sorted({r["food_id"] for r in piano if r["food_id"] not in db})
    if sconosciuti:
        raise ValueError(
            f"food_id assenti dal database: {', '.join(sconosciuti)}. "
            f"Il caso golden e' disallineato rispetto ad alimenti.csv."
        )

    per_pasto = {}
    for r in piano:
        chiave = f"{r['giorno']}|{r['pasto']}"
        per_pasto.setdefault(chiave, []).append(
            calcola_riga(db[r["food_id"]], r["grammi"]))

    totali_pasto = {k: somma_nutrienti(v) for k, v in per_pasto.items()}
    totale_giorno = somma_nutrienti(
        [riga for righe in per_pasto.values() for riga in righe])

    return {
        "totale_giorno": {n: round(totale_giorno[n], 6) for n in NUTRIENTI_PER_100G},
        "totali_pasto": {
            k: {n: round(v[n], 6) for n in NUTRIENTI_PER_100G}
            for k, v in sorted(totali_pasto.items())
        },
    }


def confronta(atteso, ottenuto):
    """Restituisce la lista degli scostamenti trovati."""
    scostamenti = []

    for n, val_atteso in atteso["totale_giorno"].items():
        val_ott = ottenuto["totale_giorno"].get(n)
        if val_ott is None:
            scostamenti.append(f"totale giorno - {n}: nutriente assente nell'output")
        elif abs(val_ott - val_atteso) > TOLLERANZA:
            scostamenti.append(
                f"totale giorno - {n}: atteso {val_atteso}, ottenuto {val_ott}")

    pasti_attesi = set(atteso.get("totali_pasto", {}))
    pasti_ottenuti = set(ottenuto.get("totali_pasto", {}))
    for mancante in sorted(pasti_attesi - pasti_ottenuti):
        scostamenti.append(f"pasto {mancante}: atteso ma assente nell'output")
    for in_piu in sorted(pasti_ottenuti - pasti_attesi):
        scostamenti.append(f"pasto {in_piu}: presente nell'output ma non atteso")

    for chiave in sorted(pasti_attesi & pasti_ottenuti):
        for n, val_atteso in atteso["totali_pasto"][chiave].items():
            val_ott = ottenuto["totali_pasto"][chiave].get(n)
            if val_ott is None or abs(val_ott - val_atteso) > TOLLERANZA:
                scostamenti.append(
                    f"pasto {chiave} - {n}: atteso {val_atteso}, ottenuto {val_ott}")

    return scostamenti


def modo_genera():
    casi = elenca_casi()
    if not casi:
        print("Nessun caso golden trovato in golden/")
        return 1
    print("MODO GENERAZIONE - gli atteso.json verranno sovrascritti.")
    print("Da usare solo se il nuovo output e' gia' stato verificato a mano.\n")
    for nome in casi:
        percorso_atteso = os.path.join(GOLDEN_DIR, nome, "atteso.json")
        try:
            risultato = esegui_caso(nome)
        except Exception as e:
            print(f"  [XX ] {nome}: {e}")
            continue
        esistente = {}
        if os.path.isfile(percorso_atteso):
            with open(percorso_atteso, encoding="utf-8") as f:
                esistente = json.load(f)
        risultato["descrizione"] = esistente.get("descrizione", "")
        risultato["riferimento"] = esistente.get("riferimento", "")
        with open(percorso_atteso, "w", encoding="utf-8") as f:
            json.dump(risultato, f, indent=2, ensure_ascii=False)
        kcal = risultato["totale_giorno"]["kcal_100g"]
        print(f"  [OK ] {nome}: atteso.json scritto (giornata {kcal:.2f} kcal)")
    return 0


def modo_verifica():
    casi = elenca_casi()
    print("=" * 60)
    print("SUITE DI REGRESSIONE - Motore di calcolo")
    print("=" * 60)

    if not casi:
        print("\nNessun caso golden trovato in golden/.")
        print("La suite e' vuota: non fornisce alcuna garanzia.")
        print("=" * 60)
        return 1

    passati, falliti = 0, 0
    for nome in casi:
        percorso_atteso = os.path.join(GOLDEN_DIR, nome, "atteso.json")
        if not os.path.isfile(percorso_atteso):
            print(f"\n  [XX ] {nome}")
            print(f"        atteso.json mancante: il caso non e' verificabile")
            falliti += 1
            continue

        with open(percorso_atteso, encoding="utf-8") as f:
            atteso = json.load(f)

        try:
            ottenuto = esegui_caso(nome)
        except Exception as e:
            print(f"\n  [XX ] {nome}")
            print(f"        errore in esecuzione: {e}")
            falliti += 1
            continue

        scostamenti = confronta(atteso, ottenuto)
        descrizione = atteso.get("descrizione", "")
        if not scostamenti:
            kcal = ottenuto["totale_giorno"]["kcal_100g"]
            print(f"\n  [OK ] {nome} ({kcal:.2f} kcal)")
            if descrizione:
                print(f"        {descrizione}")
            passati += 1
        else:
            print(f"\n  [XX ] {nome}")
            if descrizione:
                print(f"        {descrizione}")
            for s in scostamenti:
                print(f"        {s}")
            falliti += 1

    print("\n" + "=" * 60)
    print(f"RISULTATO: {passati} passati, {falliti} falliti su {len(casi)} casi")
    if falliti:
        print("SUITE ROSSA - non usare il motore su un paziente.")
        print("Capire la causa PRIMA di rigenerare qualunque atteso.json.")
    else:
        print("SUITE VERDE - il motore calcola come da riferimento.")
    print("=" * 60)
    return 1 if falliti else 0


if __name__ == "__main__":
    if "--genera" in sys.argv:
        sys.exit(modo_genera())
    sys.exit(modo_verifica())
